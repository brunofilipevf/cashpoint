<?php

/*
|--------------------------------------------------------------------------
| Definições gerais da aplicação
|--------------------------------------------------------------------------
*/

define('APP_NAME', 'CashPoint');
define('APP_AUTHOR', 'Bruno Freitas');
define('APP_DESCRIPTION', 'Sistema de CashPoint');
define('APP_TIMEZONE', 'America/Recife');

/*
|--------------------------------------------------------------------------
| Definições do banco de dados
|--------------------------------------------------------------------------
*/

define('DB_HOST', 'localhost');
define('DB_NAME', 'cashpoint');
define('DB_CHAR', 'utf8mb4');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', '3306');

/*
|--------------------------------------------------------------------------
| Definições de limites
|--------------------------------------------------------------------------
*/

define('MAX_VALUE_LIMIT_MULTIPLIER_FACTOR', '5.00');
define('MAX_VALUE_LIMIT_MANUAL_POINTS', '1000.00');
define('MAX_DAILY_LIMIT_POINTS_PER_CUSTOMER', '3');

/*
|--------------------------------------------------------------------------
| Definições de e-mail
|--------------------------------------------------------------------------
*/

define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', '465');
define('MAIL_USER', 'brunofilipevf@gmail.com');
define('MAIL_PASS', 'llovshbiwdlvonht');

/*
|--------------------------------------------------------------------------
| Definições da API
|--------------------------------------------------------------------------
*/

define('API_TOKEN', 'd32bac8e81e49e948563a6ac977f061997f68a79f7c658c8e5b1a6e8ab7ab19f');

/*
|--------------------------------------------------------------------------
| Definições do Z-API (WhatsApp)
|--------------------------------------------------------------------------
*/

define('ZAPI_URL', 'https://api.z-api.io/instances');
define('ZAPI_INSTANCE', '3F680F23091FD1604B7012472A63FE0C');
define('ZAPI_TOKEN', '3D3FB342B42E4C4A6E03E7F2');
