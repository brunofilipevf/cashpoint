$(document).ready(function() {
  $('.nav-toggle').on('click', function() {
    $('.topbar').slideToggle(300);
    $(this).toggleClass('open');
  });
});

$(document).ready(function() {
  $(document).on('click', '.delete-confirm', function(e) {
    e.preventDefault();

    const link = $(this).attr('href');

    if (confirm('Tem certeza que deseja excluir este registro?')) {
      window.location.href = link;
    }
  });
});
