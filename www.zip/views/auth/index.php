<?php $this->set('title', 'Entrar'); ?>
<?php $this->partial('base/header'); ?>

<main class="container">
    <div class="border-top">
        <div class="form-login mt-4">
            <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

            <?php $this->partial('base/flash'); ?>

            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

                <div class="mb-2">
                    <label for="username" class="mb-1">Usuário</label>
                    <input type="text" name="username" id="username" class="form-control">
                </div>

                <div class="mb-2">
                    <label for="password" class="mb-1">Senha</label>
                    <input type="password" name="password" id="password" class="form-control">
                </div>

                <button type="submit" class="btn btn-primary w-100">Entrar</button>
            </form>
        </div>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
