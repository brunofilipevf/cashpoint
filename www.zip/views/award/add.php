<?php $this->set('title', 'Adicionar premiação'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="name" class="col-md-2 col-form-label">Nome</label>
            <div class="col-md-3">
                <input
                type="text"
                name="name"
                id="name"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="product_id" class="col-md-2 col-form-label">Produto</label>
            <div class="col-md-3">
                <select name="product_id" id="product_id" class="form-select">
                    <option value="">Selecione um produto</option>
                    <?php foreach($products as $product): ?>
                        <option value="<?php echo $this->e($product['id']); ?>"><?php echo $this->e($product['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label for="required_points" class="col-md-2 col-form-label">Pontos necessários</label>
            <div class="col-md-3">
                <input
                type="text"
                name="required_points"
                id="required_points"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="max_redemption_total" class="col-md-2 col-form-label">Limite total de resgate</label>
            <div class="col-md-3">
                <input
                type="text"
                name="max_redemption_total"
                id="max_redemption_total"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="max_redemption_per_customer" class="col-md-2 col-form-label">Limite de resgate por cliente</label>
            <div class="col-md-3">
                <input
                type="text"
                name="max_redemption_per_customer"
                id="max_redemption_per_customer"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="group_id" class="col-md-2 col-form-label">Grupo exclusivo</label>
            <div class="col-md-3">
                <select name="group_id" id="group_id" class="form-select">
                    <option value="">Selecione um grupo</option>
                    <?php foreach($groups as $group): ?>
                        <option value="<?php echo $this->e($group['id']); ?>"><?php echo $this->e($group['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label for="start_date" class="col-md-2 col-form-label">Data de início</label>
            <div class="col-md-3">
                <input
                type="date"
                name="start_date"
                id="start_date"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="end_date" class="col-md-2 col-form-label">Data de término</label>
            <div class="col-md-3">
                <input
                type="date"
                name="end_date"
                id="end_date"
                class="form-control">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/awards" class="btn btn-secondary">Cancelar</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
