<?php $this->set('title', 'Editar premiação'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="name" class="col-md-2 col-form-label">Nome</label>
            <div class="col-md-3">
                <input
                type="text"
                name="name"
                id="name"
                class="form-control"
                value="<?php echo $this->e($award['name']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="product_id" class="col-md-2 col-form-label">Produto</label>
            <div class="col-md-3">
                <select name="product_id" id="product_id" class="form-select">
                    <option value="">Selecione um produto</option>
                    <?php foreach($products as $product): ?>
                        <?php $selected = ($product['id'] == $award['product_id']) ? 'selected' : ''; ?>
                        <option value="<?php echo $this->e($product['id']); ?>" <?php echo $selected; ?>>
                            <?php echo $this->e($product['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label for="required_points" class="col-md-2 col-form-label">Pontos necessários</label>
            <div class="col-md-3">
                <input
                type="text"
                name="required_points"
                id="required_points"
                class="form-control"
                value="<?php echo $this->e($award['required_points']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="max_redemption_total" class="col-md-2 col-form-label">Limite total de resgate</label>
            <div class="col-md-3">
                <input
                type="text"
                name="max_redemption_total"
                id="max_redemption_total"
                class="form-control"
                value="<?php echo $this->e($award['max_redemption_total']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="max_redemption_per_customer" class="col-md-2 col-form-label">Limite de resgate por cliente</label>
            <div class="col-md-3">
                <input
                type="text"
                name="max_redemption_per_customer"
                id="max_redemption_per_customer"
                class="form-control"
                value="<?php echo $this->e($award['max_redemption_per_customer']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="group_id" class="col-md-2 col-form-label">Grupo exclusivo</label>
            <div class="col-md-3">
                <select name="group_id" id="group_id" class="form-select">
                    <option value="">Selecione um grupo</option>
                    <?php foreach($groups as $group): ?>
                        <?php $selected = ($group['id'] == $award['group_id']) ? 'selected' : ''; ?>
                        <option value="<?php echo $this->e($group['id']); ?>" <?php echo $selected; ?>>
                            <?php echo $this->e($group['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label for="start_date" class="col-md-2 col-form-label">Data de início</label>
            <div class="col-md-3">
                <input
                type="date"
                name="start_date"
                id="start_date"
                class="form-control"
                value="<?php echo $this->e($award['start_date'], 'date:Y-m-d'); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="end_date" class="col-md-2 col-form-label">Data de término</label>
            <div class="col-md-3">
                <input
                type="date"
                name="end_date"
                id="end_date"
                class="form-control"
                value="<?php echo $this->e($award['end_date'], 'date:Y-m-d'); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="is_active" class="col-md-2 col-form-label">Status</label>
            <div class="col-md-3">
                <select name="is_active" id="is_active" class="form-select">
                    <?php $selected = ($award['is_active'] == 1) ? 'selected' : ''; ?>
                    <option value="1" <?php echo $selected; ?>>Ativo</option>
                    <?php $selected = ($award['is_active'] != 1) ? 'selected' : ''; ?>
                    <option value="0" <?php echo $selected; ?>>Inativo</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/awards" class="btn btn-secondary">Cancelar</a>
        <a href="/awards/delete/<?php echo $this->e($award['id']); ?>" class="btn btn-danger float-end delete-confirm">Excluir</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
