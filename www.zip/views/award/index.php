<?php $this->set('title', 'Premiações'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/awards/add" class="btn btn-primary">Adicionar premiação</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Produto</th>
                    <th>Pontos necessários</th>
                    <th>Data de início</th>
                    <th>Data de término</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($awards as $award): ?>
                    <tr>
                        <td><?php echo $this->e($award['id']); ?></td>
                        <td>
                            <?php echo $this->e($award['name']) . PHP_EOL; ?>
                            [<a href="/awards/edit/<?php echo $this->e($award['id']); ?>" class="small">editar</a>]
                        </td>
                        <td><?php echo $this->e($award['product_name']); ?></td>
                        <td><?php echo $this->e($award['required_points']); ?></td>
                        <td><?php echo $this->e($award['start_date'], 'date:d-m-Y'); ?></td>
                        <td><?php echo $this->e($award['end_date'], 'date:d-m-Y'); ?></td>
                        <td><?php echo $award['is_active'] == 1 ? 'Ativo' : 'Inativo'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
