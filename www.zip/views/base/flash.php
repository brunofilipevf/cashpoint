<!-- Flash -->
<?php if ($flash = $this->flash()): ?>
    <div class="alert alert-<?php echo $flash['type']; ?>">
        <?php echo $flash['content'] . PHP_EOL; ?>
    </div>
<?php endif; ?>
