<footer class="container mt-4">
    <div class="text-center border-top py-4">
        &copy; <?php echo date('Y'); ?> - <?php echo $this->get('app_name'); ?><br>
        Desenvolvido por <?php echo $this->get('app_author') . PHP_EOL; ?>
    </div>
</footer>

<script src="/assets/jquery.js"></script>
<script src="/assets/default.js"></script>

</body>
</html>
