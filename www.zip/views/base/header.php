<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="<?php echo $this->get('app_author'); ?>">
    <meta name="description" content="<?php echo $this->get('app_description'); ?>">
    <title><?php echo $this->get('title'); ?> | <?php echo $this->get('app_name'); ?></title>
    <link rel="stylesheet" type="text/css" href="/assets/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/assets/default.css">
</head>
<body>

<header class="container my-4">
    <h1 class="display-1 lh-1"><?php echo $this->get('app_name'); ?></h1>
</header>
