
<nav class="container mb-4">
    <div class="border-top border-bottom py-2">
        <div class="nav-toggle">
            Menu de navegação <span class="arrow">▼</span>
        </div>

        <ul class="topbar">
            <li><a href="/" class="<?php if ($this->isRoute('/')) echo 'active'; ?>">Início</a></li>
            <li><a href="/scores" class="<?php if ($this->isRoute('/scores')) echo 'active'; ?>">Pontuações</a></li>
            <li><a href="/redemptions" class="<?php if ($this->isRoute('/redemptions')) echo 'active'; ?>">Resgates</a></li>
            <li><a href="/customers" class="<?php if ($this->isRoute('/customers')) echo 'active'; ?>">Clientes</a></li>
            <li><a href="/groups" class="<?php if ($this->isRoute('/groups')) echo 'active'; ?>">Grupos</a></li>
            <li><a href="/awards" class="<?php if ($this->isRoute('/awards')) echo 'active'; ?>">Premiações</a></li>
            <li><a href="/products" class="<?php if ($this->isRoute('/products')) echo 'active'; ?>">Produtos</a></li>
            <li><a href="/users" class="<?php if ($this->isRoute('/users')) echo 'active'; ?>">Usuários</a></li>
            <li><a href="/companies" class="<?php if ($this->isRoute('/companies')) echo 'active'; ?>">Empresas</a></li>
            <li><a href="/logout" class="<?php if ($this->isRoute('/logout')) echo 'active'; ?>">Sair</a></li>
        </ul>
    </div>
</nav>
