<?php $this->set('title', 'Editar empresa'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="cpf" class="col-md-2 col-form-label">CPF/CNPJ</label>
            <div class="col-md-3">
                <input
                type="text"
                name="cpf"
                id="cpf"
                class="form-control"
                value="<?php echo $this->e($company['cpf']); ?>"
                disabled>
            </div>
        </div>

        <div class="row mb-2">
            <label for="name" class="col-md-2 col-form-label">Nome</label>
            <div class="col-md-3">
                <input
                type="text"
                name="name"
                id="name"
                class="form-control"
                value="<?php echo $this->e($company['name']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="is_active" class="col-md-2 col-form-label">Status</label>
            <div class="col-md-3">
                <select name="is_active" id="is_active" class="form-select">
                    <?php $selected = ($company['is_active'] == 1) ? 'selected' : ''; ?>
                    <option value="1" <?php echo $selected; ?>>Ativo</option>
                    <?php $selected = ($company['is_active'] != 1) ? 'selected' : ''; ?>
                    <option value="0" <?php echo $selected; ?>>Inativo</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/companies" class="btn btn-secondary">Cancelar</a>
        <a href="/companies/delete/<?php echo $this->e($company['id']); ?>" class="btn btn-danger float-end delete-confirm">Excluir</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
