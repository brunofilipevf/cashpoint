<?php $this->set('title', 'Empresas'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/companies/add" class="btn btn-primary">Adicionar empresa</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>CPF/CNPJ</th>
                    <th>Nome</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($companies as $company): ?>
                    <tr>
                        <td><?php echo $this->e($company['id']); ?></td>
                        <td>
                            <?php echo $this->e($company['cpf'], 'document') . PHP_EOL; ?>
                            [<a href="/companies/edit/<?php echo $this->e($company['id']); ?>" class="small">editar</a>]
                        </td>
                        <td><?php echo $this->e($company['name']); ?></td>
                        <td><?php echo $company['is_active'] == 1 ? 'Ativo' : 'Inativo'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
