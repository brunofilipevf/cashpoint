<?php $this->set('title', 'Adicionar cliente'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="cpf" class="col-md-2 col-form-label">CPF/CNPJ</label>
            <div class="col-md-3">
                <input
                type="text"
                name="cpf"
                id="cpf"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="fullname" class="col-md-2 col-form-label">Nome completo</label>
            <div class="col-md-3">
                <input
                type="text"
                name="fullname"
                id="fullname"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="email" class="col-md-2 col-form-label">E-mail</label>
            <div class="col-md-3">
                <input
                type="text"
                name="email"
                id="email"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="phone" class="col-md-2 col-form-label">Telefone</label>
            <div class="col-md-3">
                <input
                type="text"
                name="phone"
                id="phone"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="group_id" class="col-md-2 col-form-label">Grupo</label>
            <div class="col-md-3">
                <select name="group_id" id="group_id" class="form-select">
                    <option value="">Selecione um grupo</option>
                    <?php foreach($groups as $group): ?>
                        <option value="<?php echo $this->e($group['id']); ?>"><?php echo $this->e($group['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/customers" class="btn btn-secondary">Cancelar</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
