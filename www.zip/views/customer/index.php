<?php $this->set('title', 'Clientes'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/customers/add" class="btn btn-primary">Adicionar cliente</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>CPF/CNPJ</th>
                    <th>Nome completo</th>
                    <th>Grupo</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer): ?>
                    <tr>
                        <td><?php echo $this->e($customer['id']); ?></td>
                        <td>
                            <?php echo $this->e($customer['cpf'], 'document:hidden') . PHP_EOL; ?>
                            [<a href="/customers/edit/<?php echo $this->e($customer['id']); ?>" class="small">editar</a>]
                        </td>
                        <td><?php echo $this->e($customer['fullname'], 'dash'); ?></td>
                        <td><?php echo $this->e($customer['group_name'], 'dash'); ?></td>
                        <td><?php echo $customer['is_active'] == 1 ? 'Ativo' : 'Inativo'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
