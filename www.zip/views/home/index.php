<?php $this->set('title', 'Início'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p>Conteúdo aqui.</p>
</main>

<?php $this->partial('base/footer'); ?>
