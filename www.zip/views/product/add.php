<?php $this->set('title', 'Adicionar produto'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="name" class="col-md-2 col-form-label">Nome</label>
            <div class="col-md-3">
                <input
                type="text"
                name="name"
                id="name"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="barcode" class="col-md-2 col-form-label">Código de barras</label>
            <div class="col-md-3">
                <input
                type="text"
                name="barcode"
                id="barcode"
                class="form-control">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/products" class="btn btn-secondary">Cancelar</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
