<?php $this->set('title', 'Editar produto'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="name" class="col-md-2 col-form-label">Nome</label>
            <div class="col-md-3">
                <input
                type="text"
                name="name"
                id="name"
                class="form-control"
                value="<?php echo $this->e($product['name']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="barcode" class="col-md-2 col-form-label">Código de barras</label>
            <div class="col-md-3">
                <input
                type="text"
                name="barcode"
                id="barcode"
                class="form-control"
                value="<?php echo $this->e($product['barcode']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="is_active" class="col-md-2 col-form-label">Status</label>
            <div class="col-md-3">
                <select name="is_active" id="is_active" class="form-select">
                    <?php $selected = ($product['is_active'] == 1) ? 'selected' : ''; ?>
                    <option value="1" <?php echo $selected; ?>>Ativo</option>
                    <?php $selected = ($product['is_active'] != 1) ? 'selected' : ''; ?>
                    <option value="0" <?php echo $selected; ?>>Inativo</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/products" class="btn btn-secondary">Cancelar</a>
        <a href="/products/delete/<?php echo $this->e($product['id']); ?>" class="btn btn-danger float-end delete-confirm">Excluir</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
