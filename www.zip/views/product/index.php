<?php $this->set('title', 'Produtos'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/products/add" class="btn btn-primary">Adicionar produto</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Código de barras</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?php echo $this->e($product['id']); ?></td>
                        <td>
                            <?php echo $this->e($product['name']) . PHP_EOL; ?>
                            [<a href="/products/edit/<?php echo $this->e($product['id']); ?>" class="small">editar</a>]
                        </td>
                        <td><?php echo $this->e($product['barcode']); ?></td>
                        <td><?php echo $product['is_active'] == 1 ? 'Ativo' : 'Inativo'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
