<?php $this->set('title', 'Registrar resgate'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="cpf" class="col-md-2 col-form-label">CPF/CNPJ</label>
            <div class="col-md-3">
                <input
                type="text"
                name="cpf"
                id="cpf"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="award_id" class="col-md-2 col-form-label">Premiação</label>
            <div class="col-md-3">
                <select name="award_id" id="award_id" class="form-select">
                    <option value="">Selecione uma premiação</option>
                    <?php foreach($awards as $award): ?>
                        <option value="<?php echo $this->e($award['id']); ?>"><?php echo $this->e($award['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Registrar</button>
        <a href="/scores" class="btn btn-secondary">Cancelar</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
