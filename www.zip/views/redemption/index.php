<?php $this->set('title', 'Resgates'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/redemptions/add" class="btn btn-primary">Registrar resgate</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Prêmio</th>
                    <th>Usuário</th>
                    <th>Data/hora</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($redemptions as $redemption): ?>
                    <tr>
                        <td><?php echo $this->e($redemption['id']); ?></td>
                        <td>
                            <?php echo $this->e($redemption['fullname_or_cpf'], 'document:hidden') . PHP_EOL; ?>
                            [<a href="/redemptions/show/<?php echo $this->e($redemption['id']); ?>" class="small">detalhes</a>]
                        </td>
                        <td><?php echo $this->e($redemption['award_name']); ?></td>
                        <td><?php echo $this->e($redemption['username']); ?></td>
                        <td><?php echo $this->e($redemption['created_at'], 'date'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
