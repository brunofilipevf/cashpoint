<?php $this->set('title', 'Detalhes do resgate'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <tbody>
                <tr>
                    <th>Código de transação</th>
                    <td>
                        <pre class="mb-0">
                            <?php echo $this->e(implode('-', str_split($redemption['transaction_code'], 4)), 'dash'); ?>
                        </pre>
                    </td>
                </tr>
                <tr>
                    <th>Cliente</th>
                    <td><?php echo $this->e($redemption['fullname_or_cpf'], 'document:hidden'); ?></td>
                </tr>
                <tr>
                    <th>Premiação</th>
                    <td><?php echo $this->e($redemption['award_name']); ?></td>
                </tr>
                <tr>
                    <th>Pontos utilizados</th>
                    <td><?php echo $this->e($redemption['points_used']); ?></td>
                </tr>
                <tr>
                    <th>Usuário</th>
                    <td><?php echo $this->e($redemption['username']); ?></td>
                </tr>
                <tr>
                    <th>Data/Hora</th>
                    <td><?php echo $this->e($redemption['created_at'], 'date'); ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
