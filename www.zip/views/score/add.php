<?php $this->set('title', 'Registrar pontuação'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="username" class="col-md-2 col-form-label">Usuário</label>
            <div class="col-md-3">
                <input
                type="text"
                name="username"
                id="username"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="password" class="col-md-2 col-form-label">Senha</label>
            <div class="col-md-3">
                <input
                type="password"
                name="password"
                id="password"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="cpf" class="col-md-2 col-form-label">CPF/CNPJ</label>
            <div class="col-md-3">
                <input
                type="text"
                name="cpf"
                id="cpf"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="points" class="col-md-2 col-form-label">Pontos</label>
            <div class="col-md-3">
                <input
                type="text"
                name="points"
                id="points"
                class="form-control">
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Registrar</button>
        <a href="/scores" class="btn btn-secondary">Cancelar</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
