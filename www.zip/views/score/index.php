<?php $this->set('title', 'Pontuações'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/scores/add" class="btn btn-primary">Registrar pontuação</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Pontos</th>
                    <th>Usuário</th>
                    <th>Manual?</th>
                    <th>Data/hora</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scores as $score): ?>
                    <tr>
                        <td><?php echo $this->e($score['id']); ?></td>
                        <td>
                            <?php echo $this->e($score['fullname_or_cpf'], 'document:hidden') . PHP_EOL; ?>
                            [<a href="/scores/show/<?php echo $this->e($score['id']); ?>" class="small">detalhes</a>]
                        </td>
                        <td><?php echo $this->e($score['final_points']); ?></td>
                        <td><?php echo $this->e($score['username'], 'dash'); ?></td>
                        <td><?php echo $score['is_manual'] == 1 ? 'Sim' : 'Não'; ?></td>
                        <td><?php echo $this->e($score['created_at'], 'date'); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
