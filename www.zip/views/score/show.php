<?php $this->set('title', 'Detalhes da pontuação'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <tbody>
                <tr>
                    <th>Código de transação</th>
                    <td>
                        <pre class="mb-0">
                            <?php echo $this->e(implode('-', str_split($score['transaction_code'], 4)), 'dash'); ?>
                        </pre>
                    </td>
                </tr>
                <tr>
                    <th>Cliente</th>
                    <td><?php echo $this->e($score['fullname_or_cpf'], 'document:hidden'); ?></td>
                </tr>
                <tr>
                    <th>Fator multiplicador</th>
                    <td><?php echo $this->e($score['multiplier_factor']); ?></td>
                </tr>
                <tr>
                    <th>Pontos</th>
                    <td><?php echo $this->e($score['final_points']); ?></td>
                </tr>
                <tr>
                    <th>Usuário</th>
                    <td><?php echo $this->e($score['username'], 'dash'); ?></td>
                </tr>
                <tr>
                    <th>Manual?</th>
                    <td><?php echo $score['is_manual'] == 1 ? 'Sim' : 'Não'; ?></td>
                </tr>
                <tr>
                    <th>Data/Hora</th>
                    <td><?php echo $this->e($score['created_at'], 'date'); ?></td>
                </tr>
                <?php if ($score['supply_json']): ?>
                    <tr>
                        <th>Abastecimento</th>
                        <td>
                            <pre class="mb-0">
                                <?php echo $this->e(json_encode(
                                                    json_decode($score['supply_json']),
                                                    JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
                                                    'dash'); ?>
                            </pre>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
