<?php $this->set('title', 'Editar usuário'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo $this->csrf(); ?>">

        <div class="row mb-2">
            <label for="username" class="col-md-2 col-form-label">Usuário</label>
            <div class="col-md-3">
                <input
                type="text"
                name="username"
                id="username"
                class="form-control"
                value="<?php echo $this->e($user['username']); ?>"
                disabled>
            </div>
        </div>

        <div class="row mb-2">
            <label for="password" class="col-md-2 col-form-label">Senha</label>
            <div class="col-md-3">
                <input
                type="password"
                name="password"
                id="password"
                class="form-control">
            </div>
        </div>

        <div class="row mb-2">
            <label for="fullname" class="col-md-2 col-form-label">Nome completo</label>
            <div class="col-md-3">
                <input
                type="text"
                name="fullname"
                id="fullname"
                class="form-control"
                value="<?php echo $this->e($user['fullname']); ?>">
            </div>
        </div>

        <div class="row mb-2">
            <label for="level_id" class="col-md-2 col-form-label">Nível</label>
            <div class="col-md-3">
                <select name="level_id" id="level_id" class="form-select">
                    <option value="">Selecione um nível</option>
                    <?php foreach($levels as $level): ?>
                        <?php $selected = ($level['id'] == $user['level_id']) ? 'selected' : ''; ?>
                        <option value="<?php echo $this->e($level['id']); ?>" <?php echo $selected; ?>>
                            <?php echo $this->e($level['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label for="company_id" class="col-md-2 col-form-label">Empresa</label>
            <div class="col-md-3">
                <select name="company_id" id="company_id" class="form-select">
                    <option value="">Selecione uma empresa</option>
                    <?php foreach($companies as $company): ?>
                        <?php $selected = ($company['id'] == $user['company_id']) ? 'selected' : ''; ?>
                        <option value="<?php echo $this->e($company['id']); ?>" <?php echo $selected; ?>>
                            <?php echo $this->e($company['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="row mb-2">
            <label for="is_active" class="col-md-2 col-form-label">Status</label>
            <div class="col-md-3">
                <select name="is_active" id="is_active" class="form-select">
                    <?php $selected = ($user['is_active'] == 1) ? 'selected' : ''; ?>
                    <option value="1" <?php echo $selected; ?>>Ativo</option>
                    <?php $selected = ($user['is_active'] != 1) ? 'selected' : ''; ?>
                    <option value="0" <?php echo $selected; ?>>Inativo</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="/users" class="btn btn-secondary">Cancelar</a>
        <a href="/users/delete/<?php echo $this->e($user['id']); ?>" class="btn btn-danger float-end delete-confirm">Excluir</a>
    </form>
</main>

<?php $this->partial('base/footer'); ?>
