<?php $this->set('title', 'Usuários'); ?>
<?php $this->partial('base/header'); ?>
<?php $this->partial('base/navbar'); ?>

<main class="container">
    <h2 class="display-4 mb-4"><?php echo $this->get('title'); ?></h2>

    <?php $this->partial('base/flash'); ?>

    <p class="mb-2"><a href="/users/add" class="btn btn-primary">Adicionar usuário</a></p>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Usuário</th>
                    <th>Nome completo</th>
                    <th>Nível</th>
                    <th>Empresa</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $this->e($user['id']); ?></td>
                        <td>
                            <?php echo $this->e($user['username']) . PHP_EOL; ?>
                            [<a href="/users/edit/<?php echo $this->e($user['id']); ?>" class="small">editar</a>]
                        </td>
                        <td><?php echo $this->e($user['fullname']); ?></td>
                        <td><?php echo $this->e($user['level_name']); ?></td>
                        <td><?php echo $this->e($user['company_name'], 'dash'); ?></td>
                        <td><?php echo $user['is_active'] == 1 ? 'Ativo' : 'Inativo'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</main>

<?php $this->partial('base/footer'); ?>
